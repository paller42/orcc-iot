package natives.valuetest;

import net.sf.orcc.runtime.Fifo;
import net.sf.orcc.runtime.actors.IActor;

import java.net.UnknownHostException;

public class OETest<T> implements IActor {
	
	// Input FIFOs
	protected Fifo IN;  //The name of the fifo must correspond to the name of the input parameter in .cal

	
	// Actor's parameters
	// This example does not have any input params... 
	
	//Constructor
	//public OETest() {
	//}
	
	// Functions/procedures
	
	/***********
	 * Actions
	 **********/
	@Override
	public void initialize(){
		//In this example, there is nothing to initialize....
	}

	// The network class of the application will use this method to link this actor wiht others in the network.
	@Override
	@SuppressWarnings("unchecked")
	public <T> void setFifo(String portName, Fifo<T> fifo) {
		if ("IN".equals(portName)) {
			IN = (Fifo<T>) fifo;		
		} else  {
			String msg = "unknown port \"" + portName + "\"";
			throw new IllegalArgumentException(msg);
		}
	}   
	
	public int schedule() {
		boolean res;
		int i = 0;
		do {
			res = false;
			if (IN.hasTokens(1)) {
		// Your code goes here....
				int md = (int)IN.read() % 2;
				
				if( md == 0 )
					System.out.println("The value is even");
				else
					System.out.println("The value is odd");
					
		// Your code ends here....
			res = true;
			}
			i += res ? 1 : 0;
		} while (res);
		return i;
	} 
 	
}