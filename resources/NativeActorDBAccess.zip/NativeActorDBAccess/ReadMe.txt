This is the eclipse project for native DB actor
Import this project in eclipse IDE
Once imported, set the built path of your project to reference the native actor project. 
The .jar file (or the actuall implementation of the native actor) has to be in the /jars folder 
The implementation of native DBAccess actor is in NativeDBActor project. 