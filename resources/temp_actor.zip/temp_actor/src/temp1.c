// Source file is "L/RPINative/src/actors/temperature_sensor.cal"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "orcc_config.h"

#include "types.h"
#include "fifo.h"
#include "util.h"
#include "scheduler.h"
#include "dataflow.h"
#include "cycle.h"
#include "pi_2_dht_read.h"


////////////////////////////////////////////////////////////////////////////////
// Instance
extern actor_t temp1;

////////////////////////////////////////////////////////////////////////////////
// Output FIFOs
extern fifo_float_t *temp1_O;

////////////////////////////////////////////////////////////////////////////////
// Output Fifo control variables
static unsigned int index_O;
#define NUM_READERS_O 1
#define SIZE_O 512
#define tokens_O temp1_O->contents

////////////////////////////////////////////////////////////////////////////////
// Successors
extern actor_t o_port1;
time_t last_sample_time;



////////////////////////////////////////////////////////////////////////////////
// Token functions

static void write_O() {
	index_O = temp1_O->write_ind;
}

static void write_end_O() {
	temp1_O->write_ind = index_O;
}

////////////////////////////////////////////////////////////////////////////////
// Functions/procedures


////////////////////////////////////////////////////////////////////////////////
// Actions

////////////////////////////////////////////////////////////////////////////////
// Initializes

void temp1_initialize(schedinfo_t *si) {
	int i = 0;
	write_O();
finished:
	write_end_O();
	last_sample_time = 0;
	return;
}

////////////////////////////////////////////////////////////////////////////////
// Action scheduler
void temp1_scheduler(schedinfo_t *si) {
	int status;
	time_t current_time;
	float humidity,temperature;
	
	si->ports = 0;

	write_O();

	current_time = time(NULL);
	if( current_time > last_sample_time ) {
		if (1 > SIZE_O - index_O + temp1_O->read_inds[0]) {
			si->num_firings = 0;
			si->reason = full;
		} else {
			status = pi_2_dht_read(DHT22, 17, &humidity, &temperature);
			if( status != DHT_SUCCESS ) {
				printf( "Error: %d\n",status );
				si->num_firings = 0;
				si->reason = starved;
			} else {
				printf( "Temperature: %f, humidity: %f\n",temperature,humidity );
				last_sample_time = current_time;
				tokens_O[(index_O + (0)) % SIZE_O] = temperature;
				index_O += 1;
			}
		}
	} else {
		si->num_firings = 0;
		si->reason = starved;
	}
	write_end_O();
}
