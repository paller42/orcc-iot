execute mvn package to create .jar 
This is the implementation of the native actor

Copy the .jar file in the eclipse project NativeActorDBACcess, in  /jars folder  