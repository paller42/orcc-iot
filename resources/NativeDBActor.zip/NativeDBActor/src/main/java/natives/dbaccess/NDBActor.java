/*
 * Copyright (c) 2019, 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *   * Neither the name of the EPFL nor the names of its
 *     contributors may be used to endorse or promote products derived from this
 *     software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY
 * WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Authors: 	Nebojša Taušan 	<kostres@gmail.com>
 *  			Gabor Paller 	<gaborpaller@gmail.com>
 *  			Endri Bezati	<endrx>
 */

package natives.dbaccess;

import net.sf.orcc.runtime.Fifo;
import net.sf.orcc.runtime.actors.IActor;

import java.net.UnknownHostException;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoException;
import com.mongodb.WriteConcernException;

public class NDBActor<T> implements IActor {
	
	// Input FIFOs
	protected Fifo dbIN;

	
	// Actor's parameters
	public String dbTable = "" ;
	public String dbURI = "" ;
	public String actorName = "actor name";
	
	// Database 
	protected MongoClient mongoClient;
	protected DB database;
	protected DBCollection collection;
	
	//Constructor
	public NDBActor(String tblN, String uri, String actN) {
		this.dbTable = tblN;
		this.dbURI = uri;
		this.actorName = actN;
		initialize();
	
	}
	
	// Functions/procedures
	
	/***********
	 * Actions
	 **********/
	@Override
	public void initialize(){
		try {
			mongoClient = new MongoClient(new MongoClientURI(this.dbURI));
			database = mongoClient.getDB("orccdb");
			collection = database.getCollection(this.dbTable);
			System.out.println("DB initialized...");
		} catch (UnknownHostException e){
			System.out.println("UnknownHostException: " + e);
		} catch (MongoException e) {
			System.out.println("MongoException: " + e);
		}
		
	}

	
	@Override
	@SuppressWarnings("unchecked")
	public <T> void setFifo(String portName, Fifo<T> fifo) {
		if ("dbIN".equals(portName)) {
			dbIN = (Fifo<T>) fifo;		
		} else  {
			String msg = "unknown port \"" + portName + "\"";
			throw new IllegalArgumentException(msg);
		}
	}  
	
	public int schedule() {
		boolean res;
		int i = 0;
		do {
			res = false;
			if (dbIN.hasTokens(1)) {
				try{
					DBObject token = new BasicDBObject("value", dbIN.read())
								.append("actorName", this.actorName)
								.append("tStamp", System.currentTimeMillis());							
					collection.save(token);		
				} catch (WriteConcernException e) {
					System.out.println("failed to insert data into db...  " + e );
				}
				res = true;
			}
			i += res ? 1 : 0;
		} while (res);
		return i;
	} 
	 	
}